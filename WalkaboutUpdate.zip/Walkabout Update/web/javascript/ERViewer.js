var Markers = {
		types: {
			floor:{set:"setFloorMarker",draw:"drawFloorRef"},
			object:{set:"setObjectMarker",draw:"drawObjectRef"},
			door:{set:"setDoorMarker",draw:"drawDoorRef"},
			selected:{set:"setFloorMarker",draw:"drawFloorRef"},
		},
		getType: function(id){
			var i = id.indexOf("_");
			var prefix = id.substr(0,i);
			var tmp = Markers.types[prefix];
			tmp.id = prefix;
			return tmp;
		},
		generateID:function(prefix){
			return prefix+"_"+new Date().getTime()+"_"+parseInt(Math.random()*10000.0);
		},
};





function ERViewer(id,osx,osy,oswidth,osheight){
	this.id = id;
	console.debug("ERViewer "+osx+" "+osy+" "+oswidth+" "+osheight);
	this.canvas = document.getElementById(id);
	this.orientation = 0;
	this.osx = osx;
	this.osy = osy;
	this.oswidth = oswidth;
	this.osheight = osheight;
}

ERViewer.prototype.setScene = function(scene){
	this.scene = scene;
	if(scene==null){
		this.image = null;
		return;
	}
	this.image = tourManager.get_panorama(scene);
};
ERViewer.prototype.setImage = function(img){
	this.image = img;
};



ERViewer.prototype.setOrientation = function(ort){
	this.orientation = (720.0 + ort) % 360;
	this.render();
};

ERViewer.prototype.shiftHeading = function(delta){
	this.setOrientation(this.orientation+delta);
};

ERViewer.prototype.shiftHeadingByPixels = function(delta){
	var dpp = 360.0/this.oswidth;
	var d = dpp * delta;
	console.debug(d);
	this.setOrientation(this.orientation+d);
};


ERViewer.prototype.render = function(marker,marker_type){
	var ctx=this.canvas.getContext("2d");
	ctx.clearRect(this.osx, this.osy, this.oswidth, this.osheight);
	if(this.scene==null){
		return;
	}
	console.debug("OR:"+this.orientation);
	if(this.orientation==0){
		ctx.drawImage(this.image,0,0,this.image.width,this.image.height,this.osx,this.osy,this.oswidth,this.osheight);
	}
	else {
		var srcSec = calcSection(this.orientation, this.image.width);
		var destSec = calcSection(this.orientation, this.oswidth);
	
		ctx.drawImage(this.image,0,0,srcSec.subwidth,this.image.height,this.osx+destSec.offset,this.osy,destSec.subwidth,this.osheight);
		ctx.drawImage(this.image,srcSec.subwidth,0,srcSec.offset,this.image.height,this.osx,this.osy,destSec.offset,this.osheight);
	}

	if(marker){
		//console.debug("Drawing "+key);
		var type = Markers.types[marker_type];
		this[type.draw](marker,true);
	}
};


ERViewer.prototype.drawFloorRef = function(floor_ref,selected){
	var x = this.lonToX(floor_ref.lon);
	var y = this.latToY(floor_ref.lat);
	
	var ctx=this.canvas.getContext("2d");
	if(selected){
		ctx.strokeStyle = '#0000ff';
		ctx.lineWidth = 3;
	}
	else {
		ctx.strokeStyle = '#000000';	
		ctx.lineWidth = 1;
	}
	ctx.beginPath();
	ctx.moveTo(x-20,y);
	ctx.lineTo(x+20,y);
	ctx.stroke();
	
	ctx.beginPath();
	ctx.moveTo(x,y-20);
	ctx.lineTo(x,y+20);
	ctx.stroke();
};

ERViewer.prototype.drawDoorRef = function(door_ref,selected){
	var x = this.lonToX(door_ref.lon);
	var y = this.latToY(door_ref.lat);
	
	var ctx=this.canvas.getContext("2d");
	if(selected){
		ctx.strokeStyle = '#0000ff';
		ctx.lineWidth = 20;
	}
	else {
		ctx.strokeStyle = '#000000';	
		ctx.lineWidth = 20;
	}
	
	ctx.beginPath();
	ctx.moveTo(x,y-20);
	ctx.lineTo(x,y+20);
	ctx.stroke();
};

ERViewer.prototype.drawObjectRef = function(obj_ref,selected){
	var x = this.lonToX(obj_ref.lon);
	var y = this.latToY(obj_ref.lat);
	if(obj_ref.lat2==null){
		obj_ref.lat2 = obj_ref.lat + 10;
	}
	var y2 = this.latToY(obj_ref.lat2)+3; 
	
	var ctx=this.canvas.getContext("2d");
	if(selected){
		ctx.strokeStyle = '#0000ff';
		ctx.lineWidth = 3;
	}
	else {
		ctx.strokeStyle = '#000000';	
		ctx.lineWidth = 1;
	}
	ctx.beginPath();
	ctx.moveTo(x-20,y);
	ctx.lineTo(x+20,y);
	ctx.stroke();
	
	ctx.beginPath();
	ctx.moveTo(x-20,y2);
	ctx.lineTo(x+20,y2);
	ctx.stroke();
	
};

ERViewer.prototype.lonToX = function(lon){
	var x = (this.oswidth/360.0) * ((lon+180.0) % 360.0);
	return x + this.osx;
};

ERViewer.prototype.latToY = function(lat){
	var y = (this.osheight/180) * lat;
	return y + this.osy;
};

ERViewer.prototype.xToLon = function(x){
	x-=this.osx;
	lon = (((x/this.oswidth) * 360.0) + 180.0) % 360.0;
	return lon;
};

ERViewer.prototype.yToLat = function(y){
	y-=this.osy;
	lat = (y/this.osheight) * 180.0;
	return lat;
};

ERViewer.prototype.inBoundingBox = function(x,y){
	x-=this.osx;
	y-=this.osy;
	return x > 0 && x < this.oswidth && y > 0 && y < this.osheight;
};

ERViewer.prototype.toLatLon = function(x,y){
	if(this.inBoundingBox(x, y)){
		return {
			lon: this.xToLon(x),
			lat: this.yToLat(y)
		}
	}
	else {
		return null;
	}
};
ERViewer.prototype.toXY = function(ll){
	return {
		x: this.lonToX(ll.lon),
		y: this.latToY(ll.lat)
	};
};


ERViewer.prototype.setFloorMarker = function(ll,mid){
	if(!this.scene.markers){
		this.scene.markers = {};
	}
	this.scene.markers[mid] = ll;
};

ERViewer.prototype.setDoorMarker = function(ll,mid){
	if(!this.scene.markers){
		this.scene.markers = {};
	}
	this.scene.markers[mid] = ll;
};


ERViewer.prototype.findExisting = function(x,y){
	if(!this.inBoundingBox(x, y)){
		return null;
	}
	for(var key in this.scene.markers){
		var obj = this.scene.markers[key];
		var tmpx = this.lonToX(obj.lon)-x;
		var tmpy = this.latToY(obj.lat)-y;
		var tmp = tmpx*tmpx + tmpy*tmpy;
		var distance = Math.sqrt(tmp);
		if(distance < 20){
			return key;
		}
	}
	return null;	
};

ERViewer.prototype.tryMarker = function(x,y,selected_marker,marker_type,e,skip_selecting){
	var ll = this.toLatLon(x, y);
	console.debug(ll);
	if(!ll){
		return null;
	}
	if(!skip_selecting){
		if(this.scene.markers){
			var tmp = this.findExisting(x, y);
			if(tmp){
				return tmp;
			}
		}
	}
	if(selected_marker){
		var type = Markers.getType(selected_marker);
		this[type.set](ll,selected_marker);
		return selected_marker;
	}
	var type = Markers.types[marker_type];
	var marker_id = Markers.generateID(marker_type);
	this[type.set](ll,marker_id);

	selected_marker = marker_id;
	return selected_marker;
};


