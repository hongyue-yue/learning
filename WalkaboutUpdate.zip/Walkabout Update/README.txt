Installation instructions:
1. Unzip WalkaboutWorldsEditor.zip
2. If you do not have Java 8 installed, install Java 8 from here: http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html
3. In the unzipped folder, double click on Launch.bat
-This will open a command window
-This will also open your browser to the Walkabout List page
-Do not close the command window until you are done working

Quickstart:
1. On the Walkabout List page (localhost:4567/walkaboutlist.html), click "Create New Walkabout"
2. Enter the name of your new Walkabout and click OK
3. You will be directed to the Walkabout editor page
4. Drag the 360 images for your Walkabout on the place where it says "Drop files here to upload"
5. Wait for photos to finish uploading.
6. Initially, photos will appear under "Unassigned".  Click on multiple photos to select them.  Then click on "Assign Selected To Room" to assign them to a room (or in your case, think of room as a floor of a building)
7. Be sure to click "Save" peridocally
8. Once you have assigned all photos to rooms, look at all the photos and make sure they are oriented the same way. To adjust the orientation of a photo, click the "<" or ">" buttons next to the photo
9. In the header for each room, you will see a place the says "Drag Floor Plan Here".  Drag the floor plan for each floor to the each floor onto the correct header.  Make sure each floor plan file has a unique name (like "FloorPlan1.jpg","FloorPlan2.jpg",etc).  All the floor plan images are stored in the same place, so if they have the same name they will overwrite each other.
10. At the top of the page, click on the button "In Line Tour Editor"
11. The tour will launch.
12. For each room (or floor) select it with the drop down menu at the top right.
13. Click on "Floor Plan"
14. Click on a marker to move view the image associated with it
15. Drag the marker to the correct place on the floor plan.
16. Be sure to click "Save" often.  (I will implement auto save later)
